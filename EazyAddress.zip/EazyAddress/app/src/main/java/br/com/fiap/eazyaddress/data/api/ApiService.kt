package br.com.fiap.eazyaddress.data.api

import br.com.fiap.eazyaddress.data.model.Endereco
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

interface ApiService {
    @GET("cep/{cep}")
    suspend fun getCep(@Path("cep") cep: String):
            Response<Endereco>
    @GET("addresses")
    suspend fun getEnderecos(): Response<List<Endereco>>
    @POST("addresses")
    suspend fun criarEndereco(@Body address: Endereco):
            Response<Endereco>
    @PUT("addresses/{id}")
    suspend fun atualizarEndereco(@Path("id") id: Int, @Body
    address: Endereco): Response<Endereco>
    @DELETE("addresses/{id}")
    suspend fun deletarEndereco(@Path("id") id: Int):
            Response<Unit>
}