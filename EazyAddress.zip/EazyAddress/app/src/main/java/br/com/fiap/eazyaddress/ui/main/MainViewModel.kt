package br.com.fiap.eazyaddress.ui.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import br.com.fiap.eazyaddress.data.model.Endereco
import br.com.fiap.eazyaddress.data.model.EnderecoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class UiState {
    object Loading : UiState()
    data class Success(val enderecos: List<Endereco>) : UiState()
    data class Error(val mensagem: String) : UiState()
}

class MainViewModel(private val repo: EnderecoRepository =
    EnderecoRepository()) : ViewModel() {

    private val _state =
        MutableStateFlow<UiState>(UiState.Loading)
    val state: StateFlow<UiState> = _state
    init { loadAddresses() }

    fun loadAddresses() {
        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                val resp = repo.getAll()
                if (resp.isSuccessful) {
                    _state.value = UiState.Success(resp.body()
                        ?: emptyList())
                } else {
                    _state.value = UiState.Error("Erro:${resp.code()}")
                }
            } catch (e: Exception) {
                _state.value = UiState.Error(e.message ?: "Erro desconhecido")
            }
        }
    }
    fun deleteAddress(id: Int) {
        viewModelScope.launch {
            try {
                val resp = repo.delete(id)
                if (resp.isSuccessful) loadAddresses()
                else _state.value = UiState.Error("Erro ao deletar: ${resp.code()}")
            } catch (e: Exception) {
                _state.value = UiState.Error(e.message ?: "Erro desconhecido")
            }
        }
    }
}