package br.com.fiap.eazyaddress.ui.form

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import br.com.fiap.eazyaddress.data.model.Endereco
import br.com.fiap.eazyaddress.data.model.EnderecoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class FormState {
    object Idle : FormState()
    object Loading : FormState()
    data class Success(val endereco: Endereco) : FormState()
    data class Saved(val endereco: Endereco) : FormState()
    data class Error(val mensagem: String) : FormState()
}
class FormViewModel(private val repo: EnderecoRepository =
                        EnderecoRepository()) : ViewModel() {
    private val _state =
        MutableStateFlow<FormState>(FormState.Idle)
    val state: StateFlow<FormState> = _state
    fun buscaCep(cep: String) {
        _state.value = FormState.Loading
        viewModelScope.launch {
            try {
                val resp = repo.getCep(cep)
                if (resp.isSuccessful && resp.body() != null )
                {
                    _state.value =
                        FormState.Success(resp.body()!!)
                } else {
                    _state.value = FormState.Error("CEP não encontrado")
                }
            } catch (e: Exception) {
                _state.value = FormState.Error(e.message ?:
                "Erro ao buscar CEP")
            }
        }
    }
    fun salvar(endereco: Endereco) {
        _state.value = FormState.Loading
        viewModelScope.launch {
            try {
                val resp = repo.create(endereco)
                if (resp.isSuccessful && resp.body() != null) {
                    _state.value =
                        FormState.Saved(resp.body()!!)
                } else {
                    _state.value = FormState.Error("Erro ao salvar: ${resp.code()}")
                }
            } catch (e: Exception) {
                _state.value = FormState.Error(e.message ?:
                "Erro ao salvar")
            }
        }
    }
    fun atualizar(id: Int, endereco: Endereco) {
        _state.value = FormState.Loading
        viewModelScope.launch {
            try {
                val resp = repo.update(id, endereco)
                if (resp.isSuccessful && resp.body() != null) {
                    _state.value =
                        FormState.Saved(resp.body()!!)
                } else {
                    _state.value = FormState.Error("Erro ao atualizar: ${resp.code()}")
                }
            } catch (e: Exception) {
                _state.value = FormState.Error(e.message ?:
                "Erro ao atualizar")
            }
        }
    }
}