package br.com.fiap.eazyaddress.ui.form

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import br.com.fiap.eazyaddress.R
import br.com.fiap.eazyaddress.data.model.Endereco
import br.com.fiap.eazyaddress.databinding.ActivityFormBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class FormActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_ADDRESS_ID = "extra_address_id"
    }
    private lateinit var binding: ActivityFormBinding
    private val vm: FormViewModel by viewModels()
    private var editingId: Int? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFormBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // spinner
        val adapterSpinner =
            ArrayAdapter.createFromResource(this, R.array.tipos_endereco,
                android.R.layout.simple_spinner_item)

        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerTipoEndereco.adapter = adapterSpinner
        // se vier extras, preencher (edição)
        editingId = intent.getIntExtra(EXTRA_ADDRESS_ID,
            -1).takeIf { it != -1 }
        binding.btnBuscarCep.setOnClickListener {
            val cep = binding.inputCep.text.toString().trim()
            if (cep.isNotEmpty()) vm.buscaCep(cep)
        }
        binding.btnSalvar.setOnClickListener {
            val endereco = Endereco(
                id = editingId,
                nomeUsuario =
                    binding.inputNome.text.toString().trim(),
                cep = binding.inputCep.text.toString().trim(),
                logradouro =
                    binding.inputLogradouro.text.toString().trim(),
                numero =
                    binding.inputNumero.text.toString().trim(),
                bairro =
                    binding.inputBairro.text.toString().trim(),
                cidade =
                    binding.inputCidade.text.toString().trim(),
                uf = binding.inputUf.text.toString().trim(),
                tipo =
                    binding.spinnerTipoEndereco.selectedItem.toString()
            )
            if (editingId != null) {
                vm.atualizar(editingId!!, endereco)
            } else {
                vm.salvar(endereco)
            }
        }
        observe()
    }
    private fun observe() {
        lifecycleScope.launch {
            vm.state.collectLatest{ state ->
                when (state) {
                    is FormState.Idle -> {}
                    is FormState.Loading -> { /* opcional:
mostrar progress */ }
                    is FormState.Success -> {
                        val data = state.endereco

                        binding.inputLogradouro.setText(data.logradouro)

                        binding.inputBairro.setText(data.bairro)

                        binding.inputCidade.setText(data.cidade)
                        binding.inputUf.setText(data.uf)
                        Toast.makeText(this@FormActivity, "CEP preenchido", Toast.LENGTH_SHORT).show()
                    }
                    is FormState.Saved -> {
                        Toast.makeText(this@FormActivity,
                            "Salvo com sucesso", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                    is FormState.Error -> {
                        Toast.makeText(this@FormActivity,
                            state.mensagem, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}